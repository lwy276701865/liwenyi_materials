﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace one
{
    public class SColor
    {
        //字段 field
        private double _r;
        private double _g;  //ctrl + r + r
        private double _b;

        public SColor()
        {
            R = 0;
            G = 0;
            B = 0;
        }

        public SColor(double r, double g, double b)
        {
            R = r;
            G = g;
            B = b;
        }



        public double R
        {
            get
            {
                return _r;
            }

            set
            {
                _r = value;


            }
        }

        public double G
        {
            get
            {
                return _g;
            }

            set
            {
                _g = value;


            }
        }

        public double B
        {
            get
            {
                return _b;
            }

            set
            {
                _b = value;


            }
        }
        public static SColor Blue
        {
            get
            {
                return new SColor(0, 0, 1);
            }
        }
        public static SColor White
        {
            get
            {
                return new SColor(1, 1, 1);
            }
        }
        public Color ToRGB255Color()
        {
            if (_r < 0.0)
            {
                _r = 0.0;
            }

            if (_r > 1.0)
            {
                _r = 1.0;
            }
            if (_g < 0.0)
            {
                _g = 0.0;
            }

            if (_g > 1.0)
            {
                _g = 1.0;
            }
            if (_b < 0.0)
            {
                _b = 0.0;
            }

            if (_b > 1.0)
            {
                _b = 1.0;
            }
            return Color.FromArgb((int)(R * 255), (int)(G * 255), (int)(B * 255));
        }


        public static SColor operator *(SColor color, double d)
        {
            return new SColor(d * color.R, d * color.G, d * color.B);
        }

        public static SColor operator +(SColor color1, SColor color2)
        {
            return new SColor(color1.R + color2.R, color1.G + color2.G, color1.B + color2.B);
        }
        public static SColor operator *(SColor color1, SColor color2)
        {
            return new SColor(color1.R * color2.R, color1.G * color2.G, color1.B * color2.B);
        }
        public static SColor operator *(double t, SColor color2)
        {
            return new SColor(t * color2.R, t * color2.G, t * color2.B);
        }
    }
}
