﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace one
{
    class World
    {
        List<GeometryObject> _lstGeoObj = new List<GeometryObject>();
        public void AddGeoObj(GeometryObject geoObj)
        {
            _lstGeoObj.Add(geoObj);
        }
        public void RandSphere()
        {
            Random rd = new Random();
            for (int a = -11; a < 11; a++)
            {
                for (int b = -11; b < 11; b++)
                {
                    double chooseMat = rd.NextDouble();
                    Point3D center = new Point3D(a + 0.9 * rd.NextDouble(),0.2, b + 0.9 * rd.NextDouble());
                    if ((center - new Point3D(4, 0.2, 0)).Magnitude() > 0.9)
                    {
                        if (chooseMat < 0.8)
                        {
                            AddGeoObj(new Sphere(center, 0.2, new
                           Lambert(new SColor(rd.NextDouble() * rd.NextDouble(),
                           rd.NextDouble() * rd.NextDouble(), rd.NextDouble() *
                           rd.NextDouble()), 0)));
                        }
                        else if (chooseMat < 0.95)
                        {
                            AddGeoObj(new Sphere(center, 0.2, new Metal(new
                           SColor(0.5 * (1 + rd.NextDouble()), 0.5 * (1 + rd.NextDouble()), 0.5
                           * (1 + rd.NextDouble())), 0.5 * rd.NextDouble())));
                        }
                        else
                        {
                            AddGeoObj(new Sphere(center, 0.2, new
                           DielectricsTemp(new SColor(1, 1, 1), 1.5)));
                        }
                    }
                }
            }
        }
        public void Build()
        {
            double r = 0.5;
            double h = 0.7;
            double z = -5.5;
            double kd = 0.6;
            double ks = 0.8;
            double ns = 80;
            Random rd = new Random();
            //球体
            Sphere sphere = new Sphere(new Point3D(-0.5, h - 2, z + 0.5), r);
            Material mat = new Material(kd, ks, ns, new SColor(1, 1, 1));
            sphere.Mat = mat;
            Sphere sphere2 = new Sphere(new Point3D(0, h - 1, z + 0.5), r);
            Material mat2 = new Material(kd, ks, ns, new SColor(1, 0, 0));
            sphere2.Mat = mat2;
            Sphere sphere3 = new Sphere(new Point3D(-0.5, h - 0.7, z), r);
            Material mat3 = new Material(kd, ks, ns, new SColor(0.25, 0.25, 0.24));
            sphere3.Mat = mat3;
            Sphere sphere4 = new Sphere(new Point3D(0.5, h - 0.7, z), r);
            Material mat4 = new Material(kd, ks, ns, new SColor(1, 1, 0));
            sphere4.Mat = mat4;
            Sphere sphere5 = new Sphere(new Point3D(-1, h - 0.4, z - 0.5), r);
            Material mat5 = new Material(kd, ks, ns, new SColor(1, 0, 1));
            sphere5.Mat = mat5;
            Sphere sphere6 = new Sphere(new Point3D(0, h - 0.4, z - 0.5), r);
            Material mat6 = new Material(kd, ks, ns, new SColor(0, 1, 1));
            sphere6.Mat = mat6;
            Sphere sphere7 = new Sphere(new Point3D(1, h - 0.4, z - 0.5), r);
            Material mat7 = new Material(kd, ks, ns, new SColor(0.2, 0.4, 0.8));
            sphere7.Mat = mat7;
            Sphere sphere8 = new Sphere(new Point3D(-1.5, h - 0.1, z - 1), r);
            Material mat8 = new Material(kd, ks, ns, new SColor(0.5, 0.3, 1));
            sphere8.Mat = mat8;
            Sphere sphere9 = new Sphere(new Point3D(-0.5, h - 0.1, z - 1), r);
            Material mat9 = new Material(kd, ks, ns, new SColor(0.3, 0.7, 0.5));
            sphere9.Mat = mat9;
            Sphere sphere10 = new Sphere(new Point3D(0.5, h - 0.1, z - 1), r);
            Material mat10 = new Material(kd, ks, ns, new SColor(0.2, 0.8, 0.4));
            sphere10.Mat = mat10;
            Sphere sphere11 = new Sphere(new Point3D(1.5, h - 0.1, z - 1), r);
            Material mat11 = new Material(kd, ks, ns, new SColor(0.3, 0.6, 0.4));
            sphere11.Mat = mat11;
            Sphere sphere12 = new Sphere(new Point3D(-2, h + 0.1, z - 1.5), r);
            Material mat12 = new Material(kd, ks, ns, new SColor(1, 0.3, 0.6));
            sphere12.Mat = mat12;
            Sphere sphere13 = new Sphere(new Point3D(-1, h + 0.1, z - 1.5), r);
            Material mat13 = new Material(kd, ks, ns, new SColor(0.2, 0.8, 0.2));
            sphere13.Mat = mat13;
            Sphere sphere14 = new Sphere(new Point3D(0, h + 0.1, z - 1.5), r);
            Material mat14 = new Material(kd, ks, ns, new SColor(0.8, 0.6, 0.3));
            sphere14.Mat = mat14;
            Sphere sphere15 = new Sphere(new Point3D(1, h + 0.1, z - 1.5), r);
            Material mat15 = new Material(kd, ks, ns, new SColor(0.4, 0.1, 0.3));
            sphere15.Mat = mat15;
            Sphere sphere16 = new Sphere(new Point3D(2, h + 0.1, z - 1.5), r);
            Material mat16 = new Material(kd, ks, ns, new SColor(0.5, 0.3, 1));
            sphere16.Mat = mat16;
            AddGeoObj(sphere);
            AddGeoObj(sphere2);
            AddGeoObj(sphere3);
            AddGeoObj(sphere4);
            AddGeoObj(sphere5);
            AddGeoObj(sphere6);
            AddGeoObj(sphere7);
            AddGeoObj(sphere8);
            AddGeoObj(sphere9);
            AddGeoObj(sphere10);
            AddGeoObj(sphere11);
            AddGeoObj(sphere12);
            AddGeoObj(sphere13);
            AddGeoObj(sphere14);
            AddGeoObj(sphere15);
            AddGeoObj(sphere16);
        }
        public ShadeRec HitAll(Ray ray)
        {
            double tMin = 1e10;
            ShadeRec sr = new ShadeRec();
            ShadeRec srResult = new ShadeRec();
            for (int ix = 0; ix < _lstGeoObj.Count; ix++)
            {
                if (LstGeoObj[ix].Hit(ray, sr) && (sr.HitT < tMin))
                {
                    srResult.IsHit = true;
                    srResult.HitPoint = sr.HitPoint;
                    srResult.Normal = sr.Normal;
                    srResult.HitObjMat = sr.HitObjMat;
                    srResult.HitObjGloMaterial = sr.HitObjGloMaterial;
                    tMin = sr.HitT;

                }
            }
            return srResult;
        }
        public bool ShadowHitAll(Ray ray)
        {

            for (int i = 0; i < _lstGeoObj.Count; i++)
            {
                if (_lstGeoObj[i].ShadowHit(ray))
                {
                    return true;
                }
            }
            return false;
        }
        public List<GeometryObject> LstGeoObj { get => _lstGeoObj; set => _lstGeoObj = value; }
    }
}
