﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace one
{
    class Camera
    {
        private Point3D lowerLeftCorner;
        private Vector3D horizontal;
        private Vector3D vertical;
        private Point3D origin;
        private Vector3D u = new Vector3D();
        private Vector3D v = new Vector3D();
        private Vector3D w = new Vector3D();
        private double lensRadius;
        Random random = new Random();
        public Camera(Point3D lookfrom, Point3D lookat, Vector3D vup, double vfov, double aspect, double aperture, double focusDist)
        {
            lensRadius = aperture / 2;
            double thete = vfov * Math.PI / 180;
            double halfHeight = Math.Tan(thete / 2);
            double halfWidth = aspect * halfHeight;
            origin = lookfrom;
            w = (lookfrom - lookat);
            w.Normalize();
            u = Vector3D.CrossProduct(vup, w);
            u.Normalize();
            v = Vector3D.CrossProduct(w, u);
            Vector3D lowerLeftCornerTemp = origin - halfWidth * focusDist * u - halfHeight * focusDist * v - w * focusDist;
            lowerLeftCorner = new Point3D(lowerLeftCornerTemp.X,
            lowerLeftCornerTemp.Y, lowerLeftCornerTemp.Z);
            horizontal = 2 * halfWidth * u * focusDist;
            Vertical = 2 * halfHeight * v * focusDist;
        }
        internal Point3D LowerLeftCorner
        {
            get => lowerLeftCorner; set => lowerLeftCorner = value;
        }
        internal Vector3D Horizontal
        {
            get => horizontal; set => horizontal = value;
        }
        internal Vector3D Vertical
        {
            get => vertical; set => vertical = value;
        }
        internal Point3D Origin { get => origin; set => origin = value; }
        Random rd = new Random();
        private Vector3D RandomInUnitDisk()            //find a random point in unit_disk
        {
            Vector3D p;
            do
            {
                p = 2.0 * new Vector3D(rd.NextDouble(), rd.NextDouble(), 0) - new Vector3D(1, 1, 0);
            } while (p * p >= 1.0);
            return p;
        }
        public Ray GetRay(double s, double t)
        {
            Vector3D rd = lensRadius * RandomInUnitDisk();
            Vector3D offset = u * rd.X + v * rd.Y; //偏移量，为了方便用Vector表示
            return new Ray(new Point3D(origin.X + offset.X, origin.Y +
            offset.Y, origin.Z + offset.Z), lowerLeftCorner + s * horizontal + t *
            vertical - origin - offset);
        }
    }
}
