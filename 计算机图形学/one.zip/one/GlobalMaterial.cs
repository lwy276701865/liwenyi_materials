﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace one
{
    public abstract class GlobalMaterial
    {
        SColor _attenuation;
        public double fuzz;
        public GlobalMaterial(SColor a, double fuzz)
        {
            Attenuation = a;
            Fuzz = fuzz;
        }

        public SColor Attenuation { get => _attenuation; set => _attenuation = value; }
        public double Fuzz { get => fuzz; set => fuzz = value; }

        public abstract bool scatter(Ray rayIn, ShadeRec sr, out Ray rayScatter);


    }
    public class Lambert : GlobalMaterial//主要漫反射
    {
        public Lambert(SColor clr, double fuzz) : base(clr, fuzz)
        {

        }

        public override bool scatter(Ray rayIn, ShadeRec sr, out Ray rayScatter)
        {
            Point3D target = (sr.HitPoint + sr.Normal) + Vector3D.RandomInUnitSphere();
            rayScatter = new Ray(sr.HitPoint, target - sr.HitPoint);
            return true;
        }

    }

    public class Metal : GlobalMaterial//金属材质之反射光线
    {
        public Metal(SColor clr, double fuzz) : base(clr, fuzz)
        {

        }

        private Vector3D GetReflecteDir(Vector3D v, Vector3D n)
        {
            v.Normalize();
            n.Normalize();
            return v - 2 * (v * n) * n;
        }
        public override bool scatter(Ray rayIn, ShadeRec sr, out Ray rayScatter)
        {
            Vector3D p = Vector3D.RandomInUnitSphere();
            Vector3D reflecteDir = GetReflecteDir(rayIn.Direction, sr.Normal);
            reflecteDir.Normalize();
            rayScatter = new Ray(sr.HitPoint, reflecteDir + fuzz * p);
            return (rayScatter.Direction * sr.Normal) > 0;
        }


    }

    public class DielectricsTemp : GlobalMaterial//透明物质，会折射和反射
    {

        // 此处fuzz为相对折射率
        public DielectricsTemp(SColor clr, double fuzz) : base(clr, fuzz)
        {

        }
        private Vector3D GetReflecteDir(Vector3D v, Vector3D n)
        {
            v.Normalize();
            n.Normalize();
            return v - 2 * (v * n) * n;
        }
        Random rd = new Random();

        public override bool scatter(Ray rIn, ShadeRec rec, out Ray scattered)
        {
            Vector3D outwardNormal = new Vector3D();
            Vector3D reflected = GetReflecteDir(rIn.Direction, rec.Normal);
            double niOverNt;
            double reflect_prob;
            double cosine;
            Vector3D refracted = new Vector3D();
            if (Vector3D.DotProduct(rIn.Direction, rec.Normal) > 0)
            {
                outwardNormal = rec.Normal * -1;
                niOverNt = fuzz;
                cosine = fuzz * Vector3D.DotProduct(rIn.Direction,rec.Normal) / rIn.Direction.Magnitude();
            }
            else
            {
                outwardNormal = rec.Normal;
                niOverNt = 1.0 / fuzz;
                cosine = -Vector3D.DotProduct(rIn.Direction, rec.Normal) /rIn.Direction.Magnitude();
            }
            if (Refract(rIn.Direction, outwardNormal, niOverNt,
           ref refracted))
            {
                reflect_prob = Schlick(cosine, fuzz);
            }
            else
            {
                scattered = new Ray(new Point3D(rec.HitPoint.X, rec.HitPoint.Y,rec.HitPoint.Z), reflected);
                reflect_prob = 1.0;
            }
            if (rd.NextDouble() < reflect_prob)
            {
                scattered = new Ray(new Point3D(rec.HitPoint.X, rec.HitPoint.Y,rec.HitPoint.Z), reflected);
            }
            else
            {
                scattered = new Ray(new Point3D(rec.HitPoint.X, rec.HitPoint.Y,rec.HitPoint.Z), refracted);
            }
            return true;
        }

        public static double Schlick(double cosine, double refIdx)
        {
            double r0 = (1 - refIdx) / (1 + refIdx);
            r0 = r0 * r0;
            return r0 + (1 - r0) * Math.Pow((1 - cosine), 5);
        }
        public static bool Refract(Vector3D v, Vector3D n, double niOverNt, ref Vector3D refracted)
        {
            v.Normalize();
            double dt = Vector3D.DotProduct(v, n);
            double discriminant = 1.0 - niOverNt * niOverNt * (1 - dt * dt);
            if (discriminant > 0)
            {
                refracted = niOverNt * (v - n * dt) - n *
               Math.Sqrt(discriminant);
                return true;
            }
            else
                return false;
        }
    }
}
