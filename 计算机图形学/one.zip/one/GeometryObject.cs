﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace one
{
    public abstract class GeometryObject
    {
        private Material _mat;
        private GlobalMaterial _gloMaterial;

        public abstract bool Hit(Ray ray, ShadeRec sr);
        public abstract bool ShadowHit(Ray ray);

        internal Material Mat { get => _mat; set => _mat = value; }
        public GlobalMaterial GloMaterial { get => _gloMaterial; set => _gloMaterial = value; }
    }
}
