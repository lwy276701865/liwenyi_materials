﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace one
{
    class Sphere : GeometryObject
    {
        private Point3D _center;
        private double _radius;
        public const double kEpsilon = 1e-5;
        internal Point3D Center { get => _center; set => _center = value; }
        public double Radius { get => _radius; set => _radius = value; }

        public Sphere()
        {
            this._center = new Point3D(0, 0, 0);
            this._radius = 1.0;

        }
        public Sphere(Point3D center, double radius)
        {
            this._center = center;
            this._radius = radius;
        }
        public Sphere(Point3D center, double radius, GlobalMaterial gloMat)
        {
            this._center = center;
            this._radius = radius;
            this.GloMaterial = gloMat;
        }
        public Vector3D GetNormalVector(Point3D p)
        {
            Vector3D normal = p - Center;
            normal.Normalize();
            return normal;
        }

        public override bool Hit(Ray ray, ShadeRec sr)
        {
            Vector3D oc = ray.Origin - Center;
            double a = ray.Direction * ray.Direction;
            double b = 2.0 * (ray.Direction * oc);
            double c = oc * oc - Radius * Radius;
            double delta = b * b - 4.0 * a * c;
            double t;
            if (delta > 0)
            {
                t = (-b - Math.Sqrt(delta)) / (2.0 * a);
                if (t < 0)
                {
                    t = (-b + Math.Sqrt(delta)) / (2.0 * a);
                }
                if (t > kEpsilon)
                {
                    sr.HitT = t;
                    sr.HitPoint = ray.GetPointAtRay(t);
                    sr.Normal = GetNormalVector(sr.HitPoint);
                    sr.IsHit = true;
                    sr.HitObjMat = Mat;
                    sr.HitObjGloMaterial = GloMaterial;
                    return true;
                }
                return false;
            }

            else
            {
                sr = new ShadeRec();
                return false;
            }
        }

        public override bool ShadowHit(Ray ray)
        {
            Vector3D oc = ray.Origin - Center;
            double a = ray.Direction * ray.Direction;
            double b = 2.0 * (ray.Direction * oc);
            double c = oc * oc - Radius * Radius;
            double delta = b * b - 4.0 * a * c;
            double t;
            if (delta > 0)
            {
                t = (-b - Math.Sqrt(delta)) / (2.0 * a);
                if (t > kEpsilon)
                {
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }
    }
}
