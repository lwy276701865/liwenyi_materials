﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace one
{
    public class Ray
    {
        private Point3D _origin;
        private Vector3D _direction;
        public Ray()
        {
            this.Origin = new Point3D();
            this.Direction = new Vector3D();
        }
        public Ray(Point3D origin, Vector3D direction)
        {
            this.Origin = origin;
            this.Direction = direction;
        }

        internal Point3D Origin { get => _origin; set => _origin = value; }
        internal Vector3D Direction { get => _direction; set => _direction = value; }

        public Point3D GetPointAtRay(double t)
        {
            return Origin + t * Direction;
        }
    }
}
