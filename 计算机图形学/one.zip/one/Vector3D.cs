﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace one
{

    public class Vector3D
    {
        public static Vector3D RandomInUnitSphere()
        {
            Vector3D p;
            Random r = new Random();
            do
            {
                Vector3D rndV = new Vector3D(random(),
                  random(),
                  random());

                Vector3D unitV = new Vector3D(1, 1, 1);
                p = 2.0 * rndV - unitV;

            } while (p.SquaredMagnitude() >= 1.0);

            return p;
        }
        public static double random()
        {
            var seed = Guid.NewGuid().GetHashCode();
            Random r = new Random(seed);
            int i = r.Next(0, 100000);
            return (double)i / 100000;
        }
        private double _x;
        private double _y;
        private double _z;

        public Vector3D()
        {
            this.X = 0;
            this.Y = 0;
            this.Z = 0;
        }

        public double X { get => _x; set => _x = value; }
        public double Y { get => _y; set => _y = value; }
        public double Z { get => _z; set => _z = value; }
        public Vector3D(double x, double y, double z)
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
        }
        //向量*向量
        public static double operator *(Vector3D v1, Vector3D v2)
        {
            return v1.X * v2.X + v1.Y * v2.Y + v1.Z * v2.Z;
        }
        //向量*数
        public static Vector3D operator *(Vector3D v, double d)
        {
            return new Vector3D(v.X * d, v.Y * d, v.Z * d);
        }
        //数*向量
        public static Vector3D operator *(double d, Vector3D v)
        {
            return new Vector3D(v.X * d, v.Y * d, v.Z * d);
        }
        //向量加法
        public static Vector3D operator +(Vector3D v1, Vector3D v2)
        {
            return new Vector3D(v1.X + v2.X, v1.Y + v2.Y, v1.Z + v2.Z);
        }

        /*  public static Vector3D operator +(Point3D a, Vector3D b)
          {
              return new Vector3D(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
          }*/

        public static Vector3D operator +(Vector3D a, Point3D b)
        {
            return new Vector3D(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
        }

        //向量减法
        public static Vector3D operator -(Vector3D v1, Vector3D v2)
        {
            return new Vector3D(v1.X - v2.X, v1.Y - v2.Y, v1.Z - v2.Z);
        }
        public static Vector3D operator -(Vector3D b)
        {
            return new Vector3D(-b.X, -b.Y, -b.Z);
        }

        public static Vector3D operator -(Point3D a, Vector3D b)
        {
            return new Vector3D(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
        }

        public static Vector3D operator -(Vector3D a, Point3D b)
        {
            return new Vector3D(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
        }
        //向量的模及向量的大小
        public double Magnitude()
        {
            return Math.Sqrt(X * X + Y * Y + Z * Z);
        }
        //对本向量归一化
        public void Normalize()
        {
            double d = Magnitude();
            X = X / d;
            Y = Y / d;
            Z = Z / d;

        }
        public double SquaredMagnitude()
        {
            return (X * X + Y * Y + Z * Z);
        }
        //返回本向量归一化向量，本向量不变
        public Vector3D GetNormalizeVector()
        {
            double d = Magnitude();
            return new Vector3D(X / d, Y / d, Z / d);
        }

        public static double DotProduct(Vector3D a, Vector3D b)
        {
            return a.X * b.X + a.Y * b.Y + a.Z * b.Z;
        }

        public static Vector3D CrossProduct(Vector3D a, Vector3D b)
        {
            return new Vector3D(a.Y * b.Z - a.Z * b.Y, a.Z * b.X - a.X * b.Z,
           a.X * b.Y - a.Y * b.X);
        }

    }
}
