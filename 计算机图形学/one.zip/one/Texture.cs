﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace one
{
    class Texture
    {
        Bitmap bmp = new Bitmap(100, 100);
        int hres = 100;
        int vres = 100;

        public Bitmap Bmp
        {
            get
            {
                return bmp;
            }
            set
            {
                bmp = value;
                hres = bmp.Width;
                vres = bmp.Height;
            }
        }
        public void getTextCoordinate(Vector3D hitNormal, out int row, out int column)
        {
            double r = hitNormal.Magnitude();
            hitNormal.Normalize();
            double theta = Math.Acos(hitNormal.Y);
            double phi = Math.Atan2(hitNormal.X, hitNormal.Z);
            if (phi < 0)
            {
                phi += 2.0 * Math.PI;
            }
            double u = phi / (2.0 * Math.PI);
            double v = 1 - theta / Math.PI;
            column = (int)((hres - 1) * u);
            row = (int)((vres - 1) * v);
        }
        public Color getColor(ShadeRec sr)
        {
            int row;
            int colum;
            getTextCoordinate(sr.Normal, out row, out colum);
            return bmp.GetPixel(colum, vres - row - 1);
        }
    }
}
