﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace one
{
    public class ShadeRec
    {
        private bool _isHit;
        private double _hitT;
        private Point3D _hitPoint;
        private Vector3D _normal;
        private Material _hitObjMat;
        private GlobalMaterial _hitObjGloMaterial;
        public ShadeRec()
        {
            HitPoint = new Point3D(0, 0, 0);
            Normal = new Vector3D(0, 0, 0);
            IsHit = false;
            HitT = 0;
            HitObjMat = new Material(0, 0, 0, new SColor(0, 0, 0));
            HitObjGloMaterial = null;
        }
        public bool IsHit { get => _isHit; set => _isHit = value; }
        public double HitT { get => _hitT; set => _hitT = value; }
        public GlobalMaterial HitObjGloMaterial { get => _hitObjGloMaterial; set => _hitObjGloMaterial = value; }
        internal Point3D HitPoint { get => _hitPoint; set => _hitPoint = value; }
        internal Vector3D Normal { get => _normal; set => _normal = value; }
        internal Material HitObjMat { get => _hitObjMat; set => _hitObjMat = value; }
    }
}
