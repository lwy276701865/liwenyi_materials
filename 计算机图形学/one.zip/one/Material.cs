﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace one
{
    class Material
    {
        private double _kd;//漫反射系数
        private double _ks;//镜面反射系数
        private double _ns;//镜面高光系数
        private SColor _matColor;//物体颜色
        private bool isTexture;
        public Material()
        {

        }
        public Material(double kd, double ks, double ns, SColor matColor)
        {
            _kd = kd;
            _ks = ks;
            _ns = ns;
            _matColor = matColor;
        }

        public double Kd { get => _kd; set => _kd = value; }
        public double Ks { get => _ks; set => _ks = value; }
        public double Ns { get => _ns; set => _ns = value; }
        public bool IsTexture { get => isTexture; set => isTexture = value; }
        internal SColor MatColor { get => _matColor; set => _matColor = value; }
    }
}
